package frame;

import helpers.ComboBoxItem;
import helpers.Koneksi;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class SepatuInputFrame extends JFrame {
    private JTextField idTextField;
    private JTextField namaTextField;
    private JButton simpanButton;
    private JButton batalButton;
    private JPanel buttonPanel;
    private JPanel mainPanel;
    private JComboBox JenisComboBox;
    private JRadioButton tipeARadioButton;
    private JRadioButton tipeBRadioButton;
    private ButtonGroup klasifikasiButtonGroup;


    private int id;

    public void setId(int id) {
        this.id = id;
    }

    public SepatuInputFrame() {
        simpanButton.addActionListener(this::actionPerformed);
        batalButton.addActionListener(e -> {
            dispose();
        });
        kustomisasiKomponen();
        init();
    }

    public void init() {
        setTitle("Input Sepatu");
        setContentPane(mainPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();
    }

    public void isiKomponen() {

        String findSQL = "SELECT * FROM sepatu WHERE id = ?";

        Connection c = Koneksi.getConnection();
        PreparedStatement ps;
        try {
            ps = c.prepareStatement(findSQL);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                idTextField.setText(String.valueOf(rs.getInt("id")));
                namaTextField.setText(rs.getString("nama"));
                int jenisId = rs.getInt("jenis_id");
                for (int i = 0; i < JenisComboBox.getItemCount(); i++) {
                    JenisComboBox.setSelectedIndex(i);
                    ComboBoxItem item = (ComboBoxItem) JenisComboBox.getSelectedItem();
                    if(jenisId == item.getValue()){
                        break;
                    }

                }
                String klasifikasi = rs.getString("klasifikasi");
                if(klasifikasi != null) {
                    if (klasifikasi.equals("TIPE A")) {
                        tipeARadioButton.setSelected(true);
                    } else if (klasifikasi.equals("TIPE B")) {
                        tipeBRadioButton.setSelected(true);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void kustomisasiKomponen(){
        Connection c = Koneksi.getConnection();
        String selectSQL = "SELECT * FROM jenis ORDER BY nama";

        try {
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery(selectSQL);
            JenisComboBox.addItem(new ComboBoxItem(0, "Pilih Jenis"));
            while(rs.next()){
                JenisComboBox.addItem(new ComboBoxItem(
                        rs.getInt("id"),
                        rs.getString("nama")
                ));
            }
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
        klasifikasiButtonGroup = new ButtonGroup();
        klasifikasiButtonGroup.add(tipeARadioButton);
        klasifikasiButtonGroup.add(tipeBRadioButton);
    }

    private void actionPerformed(ActionEvent e) {
        String nama = namaTextField.getText();
        if (nama.equals("")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Lengkapi Data Nama sepatu",
                    "Validasi data kosong",
                    JOptionPane.WARNING_MESSAGE
            );
            namaTextField.requestFocus();
            return;
        }

        ComboBoxItem item = (ComboBoxItem) JenisComboBox.getSelectedItem();
        int jenisId = item.getValue();
        if (jenisId == 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "Pilih Jenis",
                    "Validasi data kosong",
                    JOptionPane.WARNING_MESSAGE
            );
            JenisComboBox.requestFocus();
            return;
        }
        String klasifikasi = "";
        if(tipeARadioButton.isSelected()){
            klasifikasi = "TIPE A";
        }else if(tipeBRadioButton.isSelected()){
            klasifikasi = "TIPE B";
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "Pilih Klasifikasi",
                    "Validasi data kosong",
                    JOptionPane.WARNING_MESSAGE
            );
            JenisComboBox.requestFocus();
            return;
        }


        Connection c = Koneksi.getConnection();
        PreparedStatement ps;
        try {
            if (this.id == 0) {
                String cekSQL = "SELECT * FROM sepatu WHERE nama = ?";
                ps = c.prepareStatement(cekSQL);
                ps.setString(1, nama);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Data Nama Sepatu Sudah Ada",
                            "Validasi data sama",
                            JOptionPane.WARNING_MESSAGE
                    );
                } else {
                    String insertSQL = "INSERT INTO sepatu SET nama = ?, jenis_id = ?, " +
                                        "klasifikasi = ?";
                    ps = c.prepareStatement(insertSQL);
                    ps.setString(1, nama);
                    ps.setInt(2, jenisId);
                    ps.setString(3, klasifikasi);
                    ps.executeUpdate();
                    dispose();
                }
            } else {
                String cekSQL = "SELECT * FROM sepatu WHERE nama=? AND id!=?";
                ps = c.prepareStatement(cekSQL);
                ps.setString(1, nama);
                ps.setInt(2, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Nama Sepatu Sudah Ada",
                            "Validasi data sama",
                            JOptionPane.WARNING_MESSAGE);
                } else {

                    String updateSQL = "UPDATE sepatu SET nama=?, jenis_id = ?," +
                                "klasifikasi = ? WHERE id=?";
                    ps = c.prepareStatement(updateSQL);
                    ps.setString(1, nama);
                    ps.setInt(2, jenisId);
                    ps.setString(3, klasifikasi);
                    ps.setInt(4, id);
                    ps.executeUpdate();
                    dispose();
                }
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
}



